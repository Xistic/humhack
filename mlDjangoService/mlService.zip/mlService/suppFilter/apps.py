from django.apps import AppConfig


class SuppfilterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'suppFilter'
